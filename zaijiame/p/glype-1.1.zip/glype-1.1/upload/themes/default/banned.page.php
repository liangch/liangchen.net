<html>
<head>
   <title>403 Forbidden</title>
   <style type="text/css">
html, body {
   background: #0b1933;
   text-align: center;
}
body {
   font: 80% Tahoma;
}
#wrapper {
   margin: 100px auto;
   width: 500px;
   text-align: left;
   background: #fff;
   padding: 10px;
   border: 5px solid #ccc;
}
form { 
   margin: 5px;
   background: #eee;
   padding: 5px;
}
label {
   display: block;
}
   </style>
</head>
<body>
   <div id="wrapper">
      <h1>Forbidden</h1>
      <p>You are not permitted to use this service.</p>
   </div>
</body>
</html>