<?php

function text_theme_avatar($url, $force_large = false) {
  return '';
}

function text_theme_action_icon($url, $image_url, $text) {
  return "<a href='$url'>$text</a>";
}

?>