<?php
require('../config.php');
header('Location:'.BASE_URL);
?>