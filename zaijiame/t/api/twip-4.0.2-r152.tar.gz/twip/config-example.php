<?php
define('OAUTH_KEY','');
define('OAUTH_SECRET','');
define('BASE_URL','');
define('DEBUG',FALSE);
define('COMPRESS',FALSE);
?>
